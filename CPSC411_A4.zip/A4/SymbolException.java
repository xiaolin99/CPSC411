

/**
 * CPSC411 - Assignment 4
 * Just my own Exception
 * @author xlin
 *
 */
public class SymbolException extends Exception {


	/**
	 * @param message
	 */
	public SymbolException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
